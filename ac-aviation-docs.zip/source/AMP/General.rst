General
-------

Preface
^^^^^^^
This Maintenance Program is a part of, and shall be used in conjunction with the approved General Maintenance Manual. The program specifies the detail of Maintenance and Inspection, schedule and unscheduled, to be performed on the certain aircraft.

The detail in this program is established from the related Maintenance Manuals, publications and regulation to be used as a reference document for the company and Maintenance personnel. Therefore; it may be altered, revised and/or completely changed upon requirement specified by the manufacturer, airworthiness authority or the company. However, the approval from the Department of Civil Aviation (DCA)


| Engineering Supervisor
| AC Aviation Company Limited


Approved by:


| Engineering Supervisor
| AC Aviation Company Limited