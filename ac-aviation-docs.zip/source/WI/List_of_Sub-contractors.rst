.. _`List of Sub-contractors`:

List of Sub-contractors
-----------------------

+------+------------------------------------+
| No.  | Sub-contractor Company Name        |
+======+====================================+
| 1    | Siam General Aviation Co.Ltd.      |
+------+------------------------------------+
| 2    | Jet Aviation Singapore Pte. Ltd.   |
+------+------------------------------------+
| 3    | Hawker Pacific Singapore Pte. Ltd. |
+------+------------------------------------+
