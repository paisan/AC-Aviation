.. _`Payao Buranaphanit`:

Payao Buranaphanit
==================

.. image:: /images/Permanent/PayaoBuranaphanit.JPG
   :scale: 50 %
   :alt: Bunphot Namgthoy
   :align: center
   
Positions & Service Terms
-------------------------

	**House Keeper** *(October 2011 - Present)*

Nationality
-----------

	**Thai**	

Educations
----------
	
	**Primary School Garde 6** *(Bung Ai Jiam School)*
	
	
Professional Training
---------------------

	- *None*
	

Professional Membership & Licenses
----------------------------------
	
	*None*
	 
Certificates
------------

.. Warning:: 
	To be added.

Contact Information
-------------------

	**Address**
		69 Moo 7, Tamboon Jngngam, Amphur Noung-Ngasai, Suphanburi Province

	**Telephone**
		+66 (0)89 682 3274
	
	**Email**
		*none*

	**Emergency Contact Person**
		Mr. Sook Thongkham (Husband)	*Telephone:* +66 (0)86 895 6770