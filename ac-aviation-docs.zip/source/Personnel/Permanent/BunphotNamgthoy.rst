.. _`Bunphot Namgthoy`:

Bunphot Namgthoy
================

.. image:: /images/Permanent/BunphotNamgthoy.JPG
   :scale: 50 %
   :alt: Bunphot Namgthoy
   :align: center
   
Positions & Service Terms
-------------------------

	**Airport Licensed (DMK) Driver** *(2nd March 2015 - Present)*

Nationality
-----------

	**Thai**	

Educations
----------
	
	**Mathayom 3** *(Wat Narong School)*
	
	
Professional Training
---------------------

	- **Certificate** (Aviation Human Factor) *(Royal Sky Company Limited)*
	

Professional Membership & Licenses
----------------------------------
	
	**Thai Driving License** *(25th May 1999 - 19th May 2016)*
	 
Certificates
------------

.. Warning:: 
	To be added.

Contact Information
-------------------

	**Address**
		25/1 Moo 3, Tamboon Sripharn, Amphur Sawangha, Angthong Province

	**Telephone**
		+66 (0)96 230 8427
	
	**Email**
		*none*

	**Emergency Contact Person**
		Mrs. Ngamta Lansanthat (Wife)	*Telephone:* +66 (0)87 793 6046