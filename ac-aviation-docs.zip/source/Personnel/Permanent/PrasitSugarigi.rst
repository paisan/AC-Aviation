
Prasit Sugarigi
================
   

Positions & Service Terms
-------------------------

Nationality
-----------

	Thai	

Educations
----------

	
	
Professional Training
---------------------

	

Professional Membership & Licenses
----------------------------------
	
	
	 
Certificates
------------


Contact Information
-------------------

	**Address** 
	

	**Telephone**
	
	
	**Email**
	

	**Emergency Contact Person**