Samita Bunkerd
===============

.. image:: /images/Interns/SamitaBunkerd.jpg
   :scale: 15 %
   :alt: Samita Bunkerd
   :align: center

Positions & Service Terms
-------------------------

	**Mechanic Trainee** (June - July 2015)
	
Nationality
-----------

	**Thai**	

Educations
----------
	
	- **Mathayom 6** *Chonkanyanukoon School* Chonburi, Thailand
	
	- **Summer Course** *LSI Cambridge* Cambridgeshire, England
	
	- **Student** (Mechanical Engineering) *King Mongkut’s Institute of Technology Ladkrabang*, Thailand
	
Professional Training
---------------------

	*none*

Professional Membership & Licenses
----------------------------------
	
	*none*
	 
Certificates
------------
	
	- **Certificate** (English studies) *Language Studies International (LSI)* Cambridgeshire, England

Contact Information
-------------------

	**Address** 
		48/2 Sukhumvit Rd. Sriracha Chonburi, Thailand

	**Telephone**
		+66 (0)90 984 2622
	
	**Email**
		karoking.pang@gmail.com

	**Emergency Contact Person**
		Kularb  Kongniwatsiri, Telephone: +66 (0(89 120 9998