Assupa Ratchadanon
==================

.. image:: /images/Interns/AssupaRatchadanon.jpg
   :scale: 15 %
   :alt: Assupa Ratchadanon
   :align: center

Positions & Service Terms
-------------------------

	**Mechanic Trainee** (June - July 2015)

Nationality
-----------

	**Thai**	

Educations
----------

	- **Mathayom 6** *Ratchasima Wittayalai*, Thailand
	
	- **Student** (Electronics Engineering) *Faculty of Engineering, King Mongkut’s Institute of Technology Ladkrabang*, Thailand
	
Professional Training
---------------------

	*none*
	

Professional Membership & Licenses
----------------------------------
	
	*none*
	
	 
Certificates
------------

	*none*

Contact Information
-------------------

	**Address** 
		135/12 detudom Rd, Tambon Nai Meuang, Amphur Meuang, Nakhonratsima 

	**Telephone**
		0819080169
	
	**Email**
		Assupa_bzaa@hotmail.com

	**Emergency Contact Person**
		No name supplied, Telephone: +66 (0)81 789 0662