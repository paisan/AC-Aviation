Vitawat Suenoi
==============

.. image:: /images/Interns/VitawatSuenoi.jpg
   :scale: 15 %
   :alt: Vitawat Suenoi
   :align: center

Positions & Service Terms
-------------------------

	**Mechanic Trainee** (June - July 2015)
	
Nationality
-----------

	**Thai**	

Educations
----------
	
	- **Student** (Agricultural Engineering) *Faculty of Engineering, King Mongkut’s Institute of Technology Ladkrabang*, Thailand
	
	
Professional Training
---------------------

	*none*

Professional Membership & Licenses
----------------------------------
	
	*none*
	 
Certificates
------------

	*none*

Contact Information
-------------------

	**Address** 
		66/3 Chalongkrung 1 Rd., Ladkrabang, Ladkrabang, Bangkok, Thailand

	**Telephone**
		+66 (0(99 106 0516 
	
	**Email**
		q_suerv43@hotmail.com

	**Emergency Contact Person**
		*none*