Viroj Kiatskulthong
===================

.. image:: /images/Interns/VirojKiatskulthong.jpg
   :scale: 15 %
   :alt: Viroj Kiatskulthong
   :align: center


Positions & Service Terms
-------------------------

	**Mechanic Trainee** (June - July 2015)
	
Nationality
-----------

	**Thai**	

Educations
----------

	- **Student** (Agricultural Engineering) *Faculty of Engineering, King Mongkut’s Institute of Technology Ladkrabang*, Thailand
	
Professional Training
---------------------

	*none*
	

Professional Membership & Licenses
----------------------------------
	
	*none*
	 
Certificates
------------

	*none*

Contact Information
-------------------

	**Address** 
		14 Moo 10, Tamboon Sripattana, Kampangsean, Nakorn Prathom, Thailand

	**Telephone**
		+66 (0)87 160 4965
	
	
	**Email**
		 intheair@hotmail.com

	**Emergency Contact Person**
		*None*