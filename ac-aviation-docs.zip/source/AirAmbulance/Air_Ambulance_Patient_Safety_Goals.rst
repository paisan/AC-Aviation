Air Ambulance Patient Safety Goals
==================================

**Goal 1**


Identify patient conditions correctly.

**Goal 2**


Hold communications on a high level.

**Goal 3**

Properly prepare for each mission.

**Goal 4**

Conduct clear mission documentation.

**Goal 5**

Know the AC Air Ambulance standards SOP and Alerm codes.

**Goal 6**

Always be prepared for emergencies.

**Goal 7**

Reduce the risks of patient & aircraft acquired infections.

**Goal 8**

Make safety the primary goal in all decision-making.
